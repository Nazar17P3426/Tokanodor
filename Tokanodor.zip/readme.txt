tokanodor.exe by Underwater Banjo

---- made in c++ malware ----

------------warning!----------------

withoutnonsafety run malware getting destroyed your pc!
this is long malware

creator date: dec 13 2023
by hugopako
